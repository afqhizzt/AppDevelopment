class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // User Profile images
  static String imgChatBubbleDynamicColor =
      '$imagePath/img_chat_bubble_dynamic_color.png';

  static String imgPlusDynamicColor = '$imagePath/img_plus_dynamic_color.png';

  static String imgImage26 = '$imagePath/img_image_26.png';

  static String imgImage27 = '$imagePath/img_image_27.png';

  static String imgRectangle2 = '$imagePath/img_rectangle_2.png';

  // User Edit Profile images
  static String imgRectangle163 = '$imagePath/img_rectangle_163.png';

  static String imgRectangle2109x390 = '$imagePath/img_rectangle_2_109x390.png';

  // Common images
  static String imgEllipse9 = '$imagePath/img_ellipse_9.png';

  static String imgLiHome = '$imagePath/img_li_home.svg';

  static String imgLiSearch = '$imagePath/img_li_search.svg';

  static String imgProfile = '$imagePath/img_profile.svg';

  static String imgLiClock = '$imagePath/img_li_clock.svg';

  static String imgLiUser = '$imagePath/img_li_user.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
