import 'package:flutter/material.dart';
import 'package:lim_yong_wei_s_user_profile/presentation/user_profile_screen/user_profile_screen.dart';
import 'package:lim_yong_wei_s_user_profile/presentation/user_edit_profile_screen/user_edit_profile_screen.dart';
import 'package:lim_yong_wei_s_user_profile/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String userProfileScreen = '/user_profile_screen';

  static const String userEditProfileScreen = '/user_edit_profile_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    userProfileScreen: (context) => UserProfileScreen(),
    userEditProfileScreen: (context) => UserEditProfileScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
