import 'package:flutter/material.dart';
import 'package:lim_yong_wei_s_user_profile/core/app_export.dart';
import 'package:lim_yong_wei_s_user_profile/widgets/custom_elevated_button.dart';
import 'package:lim_yong_wei_s_user_profile/widgets/custom_icon_button.dart';

class UserEditProfileScreen extends StatelessWidget {
  const UserEditProfileScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  height: 12.v,
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: appTheme.black900,
                  ),
                ),
                SizedBox(height: 9.v),
                SizedBox(
                  height: 800.v,
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.topCenter,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 103.v),
                          decoration: AppDecoration.outlineWhiteA.copyWith(
                            borderRadius: BorderRadiusStyle.customBorderTL30,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Align(
                                alignment: Alignment.centerRight,
                                child: Padding(
                                  padding: EdgeInsets.only(right: 96.h),
                                  child: Text(
                                    "LEE MIN HO",
                                    style: theme.textTheme.headlineLarge,
                                  ),
                                ),
                              ),
                              SizedBox(height: 53.v),
                              _buildStackWithText(context),
                              SizedBox(height: 32.v),
                              Padding(
                                padding: EdgeInsets.only(left: 78.h),
                                child: Text(
                                  "Computing",
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ),
                              SizedBox(height: 30.v),
                              Align(
                                alignment: Alignment.centerRight,
                                child: Padding(
                                  padding: EdgeInsets.only(right: 11.h),
                                  child: Text(
                                    "Bachelor of Mechanical Engineering (Pure) ",
                                    textAlign: TextAlign.center,
                                    style: theme.textTheme.bodyMedium,
                                  ),
                                ),
                              ),
                              SizedBox(height: 29.v),
                              Padding(
                                padding: EdgeInsets.only(left: 78.h),
                                child: Text(
                                  "3/SEMBH",
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ),
                              SizedBox(height: 25.v),
                              Padding(
                                padding: EdgeInsets.only(left: 78.h),
                                child: Text(
                                  "Official Email",
                                  style: theme.textTheme.titleSmall,
                                ),
                              ),
                              SizedBox(height: 1.v),
                              Padding(
                                padding: EdgeInsets.only(left: 81.h),
                                child: RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "minho",
                                        style: theme.textTheme.bodyMedium,
                                      ),
                                      TextSpan(
                                        text: "@graduate.utm.my",
                                        style: theme.textTheme.bodyMedium,
                                      ),
                                    ],
                                  ),
                                  textAlign: TextAlign.left,
                                ),
                              ),
                              SizedBox(height: 2.v),
                              Padding(
                                padding: EdgeInsets.only(left: 78.h),
                                child: Text(
                                  "Secondary Email",
                                  style: theme.textTheme.titleSmall,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(left: 81.h),
                                child: Text(
                                  "minho@gmail.com",
                                  textAlign: TextAlign.center,
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ),
                              SizedBox(height: 30.v),
                              Padding(
                                padding: EdgeInsets.only(left: 83.h),
                                child: Text(
                                  "012-3456789",
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ),
                              SizedBox(height: 16.v),
                              CustomElevatedButton(
                                width: 158.h,
                                text: "UPDATE",
                                buttonStyle: CustomButtonStyles.fillRedTL24,
                                alignment: Alignment.center,
                              ),
                              SizedBox(height: 26.v),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgEllipse9,
                        height: 126.v,
                        width: 130.h,
                        alignment: Alignment.topCenter,
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgRectangle163,
                        height: 403.v,
                        width: 59.h,
                        radius: BorderRadius.circular(
                          25.h,
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: EdgeInsets.only(bottom: 160.v),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgRectangle2109x390,
                        height: 109.v,
                        width: 390.h,
                        alignment: Alignment.bottomCenter,
                      ),
                      _buildMenuList(context),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildStackWithText(BuildContext context) {
    return Container(
      height: 39.v,
      width: 387.h,
      margin: EdgeInsets.only(left: 3.h),
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: SizedBox(
              child: Divider(
                color: appTheme.black900,
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 76.h),
              child: Text(
                "A22EC0004",
                style: theme.textTheme.bodyMedium,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildMenuList(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: EdgeInsets.fromLTRB(30.h, 676.v, 27.h, 53.v),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.only(top: 24.v),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiHome,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Home",
                    style: CustomTextStyles.labelLargePoppins,
                  ),
                ],
              ),
            ),
            Spacer(),
            Padding(
              padding: EdgeInsets.only(top: 24.v),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiSearch,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Search",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 27.h,
                bottom: 18.v,
              ),
              child: CustomIconButton(
                height: 52.adaptSize,
                width: 52.adaptSize,
                padding: EdgeInsets.all(14.h),
                child: CustomImageView(
                  imagePath: ImageConstant.imgProfile,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 13.h,
                top: 24.v,
              ),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiClock,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Notification",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 20.h,
                top: 24.v,
              ),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiUser,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Profile",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
