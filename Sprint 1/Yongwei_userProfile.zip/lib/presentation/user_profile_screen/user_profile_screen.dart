import 'package:flutter/material.dart';
import 'package:lim_yong_wei_s_user_profile/core/app_export.dart';
import 'package:lim_yong_wei_s_user_profile/widgets/custom_elevated_button.dart';
import 'package:lim_yong_wei_s_user_profile/widgets/custom_icon_button.dart';

class UserProfileScreen extends StatelessWidget {
  const UserProfileScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  height: 12.v,
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: appTheme.black900,
                  ),
                ),
                SizedBox(
                  height: 815.v,
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.topCenter,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 90.v),
                          decoration: AppDecoration.outlineWhiteA.copyWith(
                            borderRadius: BorderRadiusStyle.customBorderTL30,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                  left: 43.h,
                                  right: 39.h,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(top: 118.v),
                                      child: Column(
                                        children: [
                                          CustomImageView(
                                            imagePath: ImageConstant
                                                .imgChatBubbleDynamicColor,
                                            height: 46.v,
                                            width: 44.h,
                                          ),
                                          SizedBox(height: 4.v),
                                          Text(
                                            "Message",
                                            style: theme.textTheme.labelMedium,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                        left: 23.h,
                                        bottom: 7.v,
                                      ),
                                      child: Column(
                                        children: [
                                          Text(
                                            "LEE MIN HO",
                                            style:
                                                theme.textTheme.headlineLarge,
                                          ),
                                          SizedBox(height: 13.v),
                                          Align(
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Kolej Tun Dr Ismail, UTM",
                                              style: CustomTextStyles
                                                  .labelLargeGray800,
                                            ),
                                          ),
                                          SizedBox(height: 9.v),
                                          Text(
                                            "“Enthusiast for events”",
                                            style: theme.textTheme.labelLarge,
                                          ),
                                          SizedBox(height: 25.v),
                                          CustomElevatedButton(
                                            width: 158.h,
                                            text: "FOLLOW",
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                        left: 26.h,
                                        top: 130.v,
                                      ),
                                      child: Column(
                                        children: [
                                          CustomImageView(
                                            imagePath: ImageConstant
                                                .imgPlusDynamicColor,
                                            height: 34.v,
                                            width: 38.h,
                                          ),
                                          SizedBox(height: 4.v),
                                          Align(
                                            alignment: Alignment.centerRight,
                                            child: Text(
                                              "Invite",
                                              textAlign: TextAlign.center,
                                              style:
                                                  theme.textTheme.labelMedium,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 14.v),
                              Divider(),
                              SizedBox(height: 26.v),
                              _buildUserProfileStats(context),
                              SizedBox(height: 39.v),
                              _buildUserProfilePosts(context),
                              SizedBox(height: 5.v),
                              CustomImageView(
                                imagePath: ImageConstant.imgImage26,
                                height: 190.v,
                                width: 241.h,
                                radius: BorderRadius.circular(
                                  30.h,
                                ),
                                alignment: Alignment.centerLeft,
                                margin: EdgeInsets.only(left: 17.h),
                              ),
                              SizedBox(height: 10.v),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgEllipse9,
                        height: 126.v,
                        width: 130.h,
                        alignment: Alignment.topCenter,
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgImage27,
                        height: 193.v,
                        width: 116.h,
                        radius: BorderRadius.circular(
                          30.h,
                        ),
                        alignment: Alignment.bottomRight,
                        margin: EdgeInsets.only(bottom: 138.v),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgRectangle2,
                        height: 109.v,
                        width: 390.h,
                        alignment: Alignment.bottomCenter,
                      ),
                      _buildMenuList(context),
                      CustomElevatedButton(
                        height: 22.v,
                        width: 55.h,
                        text: "edit",
                        margin: EdgeInsets.only(
                          top: 1.v,
                          right: 17.h,
                        ),
                        buttonStyle: CustomButtonStyles.fillRed,
                        alignment: Alignment.topRight,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileStats(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 18.h,
        right: 27.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: 7.v),
            child: _buildUserProfileInfo(
              context,
              userFollowers: "70",
              userFollowersNumber: "following",
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 21.h),
            child: SizedBox(
              height: 48.v,
              child: VerticalDivider(
                width: 1.h,
                thickness: 1.v,
              ),
            ),
          ),
          Spacer(
            flex: 37,
          ),
          Padding(
            padding: EdgeInsets.only(
              top: 10.v,
              bottom: 4.v,
            ),
            child: _buildUserProfileInfo(
              context,
              userFollowers: "followers",
              userFollowersNumber: "700",
            ),
          ),
          Spacer(
            flex: 41,
          ),
          SizedBox(
            height: 48.v,
            child: VerticalDivider(
              width: 1.h,
              thickness: 1.v,
            ),
          ),
          Spacer(
            flex: 20,
          ),
          Container(
            height: 34.v,
            width: 35.h,
            margin: EdgeInsets.only(
              top: 10.v,
              bottom: 2.v,
            ),
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Text(
                    "posts",
                    style: theme.textTheme.labelLarge,
                  ),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: Text(
                    "10",
                    style: theme.textTheme.labelLarge,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfilePosts(BuildContext context) {
    return SizedBox(
      height: 30.v,
      width: 387.h,
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          Align(
            alignment: Alignment.center,
            child: SizedBox(
              child: Divider(
                color: appTheme.black900,
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 12.h),
              child: Text(
                "POSTS",
                textAlign: TextAlign.center,
                style: theme.textTheme.labelLarge,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildMenuList(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: EdgeInsets.fromLTRB(30.h, 690.v, 27.h, 54.v),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.only(top: 24.v),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiHome,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Home",
                    style: CustomTextStyles.labelLargePoppins,
                  ),
                ],
              ),
            ),
            Spacer(),
            Padding(
              padding: EdgeInsets.only(top: 24.v),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiSearch,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Search",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 27.h,
                bottom: 18.v,
              ),
              child: CustomIconButton(
                height: 52.adaptSize,
                width: 52.adaptSize,
                padding: EdgeInsets.all(14.h),
                child: CustomImageView(
                  imagePath: ImageConstant.imgProfile,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 13.h,
                top: 24.v,
              ),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiClock,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Notification",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 20.h,
                top: 24.v,
              ),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiUser,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Profile",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildUserProfileInfo(
    BuildContext context, {
    required String userFollowers,
    required String userFollowersNumber,
  }) {
    return SizedBox(
      height: 32.v,
      width: 62.h,
      child: Stack(
        alignment: Alignment.topLeft,
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: Text(
              userFollowers,
              style: theme.textTheme.labelLarge!.copyWith(
                color: appTheme.black900,
              ),
            ),
          ),
          Align(
            alignment: Alignment.topLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 16.h),
              child: Text(
                userFollowersNumber,
                style: theme.textTheme.labelLarge!.copyWith(
                  color: appTheme.black900,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
