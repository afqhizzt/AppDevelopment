import 'package:flutter/material.dart';
import 'package:chew_xin_shi_b22ec0017_s_club_profile/presentation/club_profile_screen/club_profile_screen.dart';
import 'package:chew_xin_shi_b22ec0017_s_club_profile/presentation/club_edit_profile_screen/club_edit_profile_screen.dart';
import 'package:chew_xin_shi_b22ec0017_s_club_profile/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String clubProfileScreen = '/club_profile_screen';

  static const String clubEditProfileScreen = '/club_edit_profile_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    clubProfileScreen: (context) => ClubProfileScreen(),
    clubEditProfileScreen: (context) => ClubEditProfileScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
