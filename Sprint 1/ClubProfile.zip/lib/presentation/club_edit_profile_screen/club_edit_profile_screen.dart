import 'package:chew_xin_shi_b22ec0017_s_club_profile/core/app_export.dart';
import 'package:chew_xin_shi_b22ec0017_s_club_profile/widgets/custom_elevated_button.dart';
import 'package:chew_xin_shi_b22ec0017_s_club_profile/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class ClubEditProfileScreen extends StatelessWidget {
  const ClubEditProfileScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  height: 12.v,
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: appTheme.black900,
                  ),
                ),
                SizedBox(height: 2.v),
                SizedBox(
                  height: 818.v,
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.topCenter,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 103.v),
                          decoration: AppDecoration.outlineWhiteA.copyWith(
                            borderRadius: BorderRadiusStyle.customBorderTL30,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(right: 73.h),
                                child: Text(
                                  "AKSARA RESAK",
                                  style: theme.textTheme.headlineLarge,
                                ),
                              ),
                              SizedBox(height: 53.v),
                              _buildAksaraResakStack(context),
                              SizedBox(height: 28.v),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: EdgeInsets.only(left: 21.h),
                                  child: Row(
                                    children: [
                                      CustomImageView(
                                        imagePath:
                                            ImageConstant.imgRectangle165,
                                        height: 50.v,
                                        width: 56.h,
                                        radius: BorderRadius.circular(
                                          25.h,
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(
                                          left: 5.h,
                                          top: 16.v,
                                          bottom: 12.v,
                                        ),
                                        child: Text(
                                          "L50 , UTM",
                                          style: theme.textTheme.bodyMedium,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              SizedBox(height: 137.v),
                              CustomElevatedButton(
                                width: 158.h,
                                text: "UPDATE",
                                margin: EdgeInsets.only(right: 106.h),
                                buttonStyle: CustomButtonStyles.fillRedTL24,
                              ),
                              SizedBox(height: 47.v),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgEllipse6,
                        height: 126.v,
                        width: 130.h,
                        radius: BorderRadius.circular(
                          65.h,
                        ),
                        alignment: Alignment.topCenter,
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgRectangle171,
                        height: 109.v,
                        width: 390.h,
                        alignment: Alignment.bottomCenter,
                        margin: EdgeInsets.only(bottom: 15.v),
                      ),
                      _buildMenuListRow(context),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAksaraResakStack(BuildContext context) {
    return SizedBox(
      height: 167.v,
      width: 387.h,
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: SizedBox(
              child: Divider(
                color: appTheme.black900,
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomLeft,
            child: Padding(
              padding: EdgeInsets.only(
                left: 74.h,
                bottom: 9.v,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Official Email",
                    style: theme.textTheme.titleSmall,
                  ),
                  SizedBox(height: 9.v),
                  Text(
                    "aksararesakk@utm.my",
                    style: theme.textTheme.bodyMedium,
                  ),
                  SizedBox(height: 30.v),
                  Text(
                    "012-3456789",
                    style: theme.textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgRectangle163,
            height: 145.v,
            width: 46.h,
            radius: BorderRadius.circular(
              23.h,
            ),
            alignment: Alignment.bottomLeft,
            margin: EdgeInsets.only(left: 17.h),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildMenuListRow(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: EdgeInsets.fromLTRB(34.h, 678.v, 23.h, 69.v),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.only(top: 24.v),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiHome,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Home",
                    style: CustomTextStyles.labelLargePoppins,
                  ),
                ],
              ),
            ),
            Spacer(),
            Padding(
              padding: EdgeInsets.only(top: 24.v),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiSearch,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Search",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 27.h,
                bottom: 18.v,
              ),
              child: CustomIconButton(
                height: 52.adaptSize,
                width: 52.adaptSize,
                padding: EdgeInsets.all(14.h),
                child: CustomImageView(
                  imagePath: ImageConstant.imgProfile,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 13.h,
                top: 24.v,
              ),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiClock,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Notification",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 20.h,
                top: 24.v,
              ),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiUser,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Profile",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
