import 'package:chew_xin_shi_b22ec0017_s_club_profile/core/app_export.dart';
import 'package:chew_xin_shi_b22ec0017_s_club_profile/widgets/custom_elevated_button.dart';
import 'package:chew_xin_shi_b22ec0017_s_club_profile/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class ClubProfileScreen extends StatelessWidget {
  const ClubProfileScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  height: 12.v,
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: appTheme.black900,
                  ),
                ),
                SizedBox(
                  height: 831.v,
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.bottomCenter,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 90.v),
                          decoration: AppDecoration.outlineWhiteA.copyWith(
                            borderRadius: BorderRadiusStyle.customBorderTL30,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "AKSARA RESAK",
                                style: theme.textTheme.headlineLarge,
                              ),
                              SizedBox(height: 13.v),
                              Text(
                                "Kolej Tun Dr Ismail, UTM",
                                style: CustomTextStyles.labelLargeGray800,
                              ),
                              SizedBox(height: 10.v),
                              Text(
                                "“Where rhythms connect and friendship resonate”",
                                style: theme.textTheme.labelLarge,
                              ),
                              SizedBox(height: 20.v),
                              _buildUserProfileSection(context),
                              SizedBox(height: 14.v),
                              Divider(),
                              SizedBox(height: 26.v),
                              _buildLikesSection(context),
                              SizedBox(height: 43.v),
                              _buildPostsSection(context),
                              SizedBox(height: 18.v),
                              CustomImageView(
                                imagePath: ImageConstant.imgRectangle161,
                                height: 171.v,
                                width: 225.h,
                                radius: BorderRadius.circular(
                                  25.h,
                                ),
                                alignment: Alignment.centerLeft,
                                margin: EdgeInsets.only(left: 11.h),
                              ),
                              SizedBox(height: 72.v),
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgRectangle167,
                        height: 109.v,
                        width: 390.h,
                        alignment: Alignment.bottomCenter,
                        margin: EdgeInsets.only(bottom: 13.v),
                      ),
                      _buildMenuListSection(context),
                      CustomImageView(
                        imagePath: ImageConstant.imgEllipse6,
                        height: 126.v,
                        width: 130.h,
                        radius: BorderRadius.circular(
                          65.h,
                        ),
                        alignment: Alignment.topCenter,
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgRectangle162,
                        height: 171.v,
                        width: 137.h,
                        radius: BorderRadius.circular(
                          25.h,
                        ),
                        alignment: Alignment.bottomRight,
                        margin: EdgeInsets.only(bottom: 164.v),
                      ),
                      CustomElevatedButton(
                        height: 22.v,
                        width: 55.h,
                        text: "edit",
                        margin: EdgeInsets.only(right: 12.h),
                        buttonStyle: CustomButtonStyles.fillRed,
                        alignment: Alignment.topRight,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildUserProfileSection(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Padding(
        padding: EdgeInsets.only(
          left: 37.h,
          right: 16.h,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Column(
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgEllipse7,
                  height: 40.v,
                  width: 42.h,
                  radius: BorderRadius.circular(
                    21.h,
                  ),
                ),
                SizedBox(height: 4.v),
                Text(
                  "Message",
                  style: theme.textTheme.labelMedium,
                ),
              ],
            ),
            Spacer(),
            CustomElevatedButton(
              width: 158.h,
              text: "FOLLOW",
              margin: EdgeInsets.only(
                top: 4.v,
                bottom: 7.v,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(left: 9.h),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgEllipse1,
                    height: 44.adaptSize,
                    width: 44.adaptSize,
                    radius: BorderRadius.circular(
                      22.h,
                    ),
                    alignment: Alignment.centerRight,
                    margin: EdgeInsets.only(right: 19.h),
                  ),
                  SizedBox(height: 2.v),
                  Text(
                    "Turn on reminder",
                    style: theme.textTheme.labelMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildLikesSection(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.only(
          left: 12.h,
          right: 36.h,
        ),
        child: Row(
          children: [
            Padding(
              padding: EdgeInsets.symmetric(vertical: 7.v),
              child: _buildFollowersSection(
                context,
                userFollowers: "70",
                userFollowersNumber: "following",
              ),
            ),
            Padding(
              padding: EdgeInsets.only(left: 21.h),
              child: SizedBox(
                height: 48.v,
                child: VerticalDivider(
                  width: 1.h,
                  thickness: 1.v,
                ),
              ),
            ),
            Spacer(
              flex: 37,
            ),
            Padding(
              padding: EdgeInsets.only(
                top: 10.v,
                bottom: 4.v,
              ),
              child: _buildFollowersSection(
                context,
                userFollowers: "followers",
                userFollowersNumber: "700",
              ),
            ),
            Spacer(
              flex: 41,
            ),
            SizedBox(
              height: 48.v,
              child: VerticalDivider(
                width: 1.h,
                thickness: 1.v,
              ),
            ),
            Spacer(
              flex: 21,
            ),
            Container(
              height: 35.v,
              width: 30.h,
              margin: EdgeInsets.only(top: 10.v),
              child: Stack(
                alignment: Alignment.topRight,
                children: [
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Text(
                      "likes",
                      style: theme.textTheme.labelLarge,
                    ),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: EdgeInsets.only(right: 5.h),
                      child: Text(
                        "7K",
                        style: theme.textTheme.labelLarge,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildPostsSection(BuildContext context) {
    return SizedBox(
      height: 33.v,
      width: 385.h,
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: SizedBox(
              child: Divider(
                color: appTheme.black900,
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 9.h),
              child: Text(
                "POSTS",
                textAlign: TextAlign.center,
                style: theme.textTheme.labelLarge,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildMenuListSection(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: EdgeInsets.fromLTRB(31.h, 693.v, 26.h, 67.v),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsets.only(top: 24.v),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiHome,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Home",
                    style: CustomTextStyles.labelLargePoppins,
                  ),
                ],
              ),
            ),
            Spacer(),
            Padding(
              padding: EdgeInsets.only(top: 24.v),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiSearch,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Search",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 27.h,
                bottom: 18.v,
              ),
              child: CustomIconButton(
                height: 52.adaptSize,
                width: 52.adaptSize,
                padding: EdgeInsets.all(14.h),
                child: CustomImageView(
                  imagePath: ImageConstant.imgProfile,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 13.h,
                top: 24.v,
              ),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiClock,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Notification",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                left: 20.h,
                top: 24.v,
              ),
              child: Column(
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgLiUser,
                    height: 24.adaptSize,
                    width: 24.adaptSize,
                  ),
                  SizedBox(height: 4.v),
                  Text(
                    "Profile",
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Common widget
  Widget _buildFollowersSection(
    BuildContext context, {
    required String userFollowers,
    required String userFollowersNumber,
  }) {
    return SizedBox(
      height: 32.v,
      width: 62.h,
      child: Stack(
        alignment: Alignment.topLeft,
        children: [
          Align(
            alignment: Alignment.bottomCenter,
            child: Text(
              userFollowers,
              style: theme.textTheme.labelLarge!.copyWith(
                color: appTheme.black900,
              ),
            ),
          ),
          Align(
            alignment: Alignment.topLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 16.h),
              child: Text(
                userFollowersNumber,
                style: theme.textTheme.labelLarge!.copyWith(
                  color: appTheme.black900,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
