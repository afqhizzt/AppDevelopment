class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Club Profile images
  static String imgEllipse7 = '$imagePath/img_ellipse_7.png';

  static String imgEllipse1 = '$imagePath/img_ellipse_1.png';

  static String imgRectangle161 = '$imagePath/img_rectangle_161.png';

  static String imgRectangle167 = '$imagePath/img_rectangle_167.png';

  static String imgRectangle162 = '$imagePath/img_rectangle_162.png';

  // Club Edit Profile images
  static String imgRectangle163 = '$imagePath/img_rectangle_163.png';

  static String imgRectangle165 = '$imagePath/img_rectangle_165.png';

  static String imgRectangle171 = '$imagePath/img_rectangle_171.png';

  // Common images
  static String imgLiHome = '$imagePath/img_li_home.svg';

  static String imgLiSearch = '$imagePath/img_li_search.svg';

  static String imgProfile = '$imagePath/img_profile.svg';

  static String imgLiClock = '$imagePath/img_li_clock.svg';

  static String imgLiUser = '$imagePath/img_li_user.svg';

  static String imgEllipse6 = '$imagePath/img_ellipse_6.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
